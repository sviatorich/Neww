package com.bumpbot

import android.content.Context
import android.content.SharedPreferences

/** Усі налаштування та «пам'ять» навчання (зберігаються між запусками). */
object Prefs {
    private var sp: SharedPreferences? = null
    fun init(c: Context) {
        if (sp == null) sp = c.applicationContext.getSharedPreferences("bumpbot", Context.MODE_PRIVATE)
    }
    private val s get() = sp!!

    // кольори (калібруються користувачем)
    var duckColor: Int
        get() = s.getInt("duck", 0xFFFFC400.toInt())
        set(v) { s.edit().putInt("duck", v).apply() }
    var obstColor: Int
        get() = s.getInt("obst", 0xFF4CAF50.toInt())
        set(v) { s.edit().putInt("obst", v).apply() }
    var tol: Int
        get() = s.getInt("tol", 55)
        set(v) { s.edit().putInt("tol", v).apply() }

    // ігрова зона (частки висоти кадру, що ігноруються зверху/знизу: інтерфейс, земля)
    var marginTop: Float
        get() = s.getFloat("mt", 0.07f)
        set(v) { s.edit().putFloat("mt", v).apply() }
    var marginBottom: Float
        get() = s.getFloat("mb", 0.10f)
        set(v) { s.edit().putFloat("mb", v).apply() }

    // точки натискання (частки екрана)
    var tapX: Float
        get() = s.getFloat("tx", 0.5f)
        set(v) { s.edit().putFloat("tx", v).apply() }
    var tapY: Float
        get() = s.getFloat("ty", 0.65f)
        set(v) { s.edit().putFloat("ty", v).apply() }
    var restartX: Float
        get() = s.getFloat("rx", 0.5f)
        set(v) { s.edit().putFloat("rx", v).apply() }
    var restartY: Float
        get() = s.getFloat("ry", 0.75f)
        set(v) { s.edit().putFloat("ry", v).apply() }

    var auto: Boolean
        get() = s.getBoolean("auto", true)
        set(v) { s.edit().putBoolean("auto", v).apply() }
    var autoRestart: Boolean
        get() = s.getBoolean("autorestart", true)
        set(v) { s.edit().putBoolean("autorestart", v).apply() }

    // параметри, яких навчається ШІ
    var g: Float          // гравітація, висот екрана / с²
        get() = s.getFloat("g", 2.2f)
        set(v) { s.edit().putFloat("g", v).apply() }
    var vj: Float         // швидкість стрибка, висот екрана / с
        get() = s.getFloat("vj", 0.7f)
        set(v) { s.edit().putFloat("vj", v).apply() }
    var bias: Float       // зсув прицілу в проміжку (-1 вище … +1 нижче)
        get() = s.getFloat("bias", 0f)
        set(v) { s.edit().putFloat("bias", v).apply() }
    var lead: Float       // випередження (затримка зчитування + жесту), с
        get() = s.getFloat("lead", 0.12f)
        set(v) { s.edit().putFloat("lead", v).apply() }

    // статистика
    var best: Int
        get() = s.getInt("best", 0)
        set(v) { s.edit().putInt("best", v).apply() }
    var attempts: Int
        get() = s.getInt("attempts", 0)
        set(v) { s.edit().putInt("attempts", v).apply() }
    var lastScore: Int
        get() = s.getInt("last", 0)
        set(v) { s.edit().putInt("last", v).apply() }
}
