package com.bumpbot

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * «Мозок». Усі координати нормовані на висоту кадру (0 = верх, 1 = низ, y росте вниз).
 *
 * Фізика: після тапу швидкість качки = -vj, далі діє гравітація g.
 * Рішення: прогнозуємо позицію через час `lead` (затримка кадру + жесту).
 * Якщо без тапу качка опиниться нижче «лінії тапу» (низ пилкоподібної траєкторії,
 * підібраний так, щоб траєкторія була по центру проміжку) — тапаємо, але тільки якщо
 * вершина стрибка не влетить у верхню перешкоду.
 *
 * Навчання:
 *  - g — квадратична регресія по кадрах вільного падіння;
 *  - vj — з висоти вершини кожного стрибка: vj = sqrt(2·g·h);
 *  - швидкість перешкод — по зсуву краю перешкоди між кадрами;
 *  - після кожного програшу — корекція прицілу (bias) та випередження (lead)
 *    залежно від того, куди влетіла качка (в нижню чи верхню частину).
 */
class Autopilot(private val w: Int, private val h: Int) {
    var g = Prefs.g
    var vj = Prefs.vj
    var bias = Prefs.bias
    var lead = Prefs.lead
    var score = 0; private set

    private var has = false
    private var y0 = 0f; private var ts0 = 0L; private var vy = 0f
    private var lastTap = 0L; private var firstTs = 0L; private var everTapped = false
    private var tracking = false; private var yTap = 0f; private var minY = 0f
    private val bt = DoubleArray(WIN); private val by = DoubleArray(WIN); private var n = 0
    private var inside = false
    private var obsSpeed = 0.45f * w
    private var prevXs = -1
    private var lastObs: Obstacle? = null
    private var lastY = 0.5f

    fun reset() {
        has = false; score = 0; inside = false; n = 0; tracking = false; lastObs = null
        firstTs = 0L; everTapped = false; vy = 0f; prevXs = -1; lastTap = 0L
    }

    /** Повертає true, якщо треба зробити тап зараз. */
    fun step(s: Scene, ts: Long, allowTap: Boolean): Boolean {
        val d = s.duck ?: return false
        val o = s.obstacle
        val y = d.y / h
        val r = d.r / h
        if (firstTs == 0L) firstTs = ts

        if (has) {
            val dt = (ts - ts0) / 1e9f
            if (dt in 0.004f..0.25f) {
                val raw = (y - y0) / dt
                // різкий стрибок вгору, якого ми не робили (тап користувача) — скидаємо вікно
                if (raw < vy - 0.45f && ts - lastTap > 150_000_000L) { lastTap = ts; tracking = false; n = 0 }
                vy = 0.5f * vy + 0.5f * raw
                if (ts - lastTap > 200_000_000L) push(ts, y) else n = 0
                // швидкість руху перешкод
                if (o != null && prevXs > 0 && o.xStart > d.x + d.r + 3 && o.xStart < w - 3) {
                    val sp = (prevXs - o.xStart) / dt
                    if (sp in 20f..(3f * w)) obsSpeed = 0.9f * obsSpeed + 0.1f * sp
                }
            }
        }
        prevXs = if (o != null && o.xStart > d.x + d.r + 3 && o.xStart < w - 3) o.xStart else -1
        has = true; y0 = y; ts0 = ts

        // вимірювання сили стрибка по вершині
        if (tracking) {
            if (y < minY) minY = y
            if (vy > 0.05f && ts - lastTap > 50_000_000L) {
                val rise = yTap - minY
                if (rise in 0.02f..0.45f) {
                    val est = sqrt(2f * g * rise).coerceIn(0.2f, 2.5f)
                    vj = 0.85f * vj + 0.15f * est
                }
                tracking = false
            } else if (ts - lastTap > 1_000_000_000L) tracking = false
        }

        // підрахунок очок: качка була в зоні перешкоди, а тепер її позаду
        val overlapping = o != null && o.xStart <= d.x + d.r && o.xEnd >= d.x - d.r
        if (overlapping) inside = true
        else if (inside) { inside = false; score++; bias *= 0.97f }

        lastObs = o; lastY = y

        // ---- рішення ----
        val rise = vj * vj / (2f * g)
        val tl = lead
        val yp = y + vy * tl + 0.5f * g * tl * tl
        val top = Prefs.marginTop
        val bot = 1f - Prefs.marginBottom
        val low: Float; val ceilY: Float; val hardFloor: Float
        if (o != null) {
            val gt = o.gapTop / h.toFloat(); val gb = o.gapBottom / h.toFloat()
            val gh = gb - gt
            val mid = (gt + gb) / 2f + bias * gh / 2f
            low = min(gb - r - 0.012f, mid + rise / 2f)
            val dist = o.xStart - (d.x + d.r)
            val near = dist <= obsSpeed * (vj / g + lead + 0.1f)
            ceilY = if (near) gt + r * 0.9f else top + r
            hardFloor = gb - r * 0.8f
        } else {
            low = min(bot - r - 0.02f, 0.5f + rise / 2f + bias * 0.1f)
            ceilY = top + r
            hardFloor = bot - r * 0.8f
        }
        var want = yp > low && (yp - rise >= ceilY || yp > hardFloor)
        if (!everTapped && ts - firstTs > 800_000_000L) want = true   // «поштовх» для старту гри

        if (want && allowTap && ts - lastTap > 90_000_000L) {
            lastTap = ts; everTapped = true
            tracking = true; yTap = y; minY = y; n = 0
            return true
        }
        return false
    }

    /** Викликається при програші: коригуємо стратегію і зберігаємо знання. */
    fun onDeath() {
        val o = lastObs
        if (o != null) {
            val mid = (o.gapTop + o.gapBottom) / 2f / h
            if (lastY > mid) { bias -= 0.06f; lead += 0.004f } else { bias += 0.06f; lead -= 0.004f }
        } else {
            if (lastY > 0.5f) { bias -= 0.03f; lead += 0.004f } else { bias += 0.03f; lead -= 0.004f }
        }
        bias = bias.coerceIn(-0.7f, 0.7f)
        lead = lead.coerceIn(0.04f, 0.30f)
        Prefs.g = g; Prefs.vj = vj; Prefs.bias = bias; Prefs.lead = lead
    }

    private fun push(t: Long, y: Float) {
        bt[n] = t / 1e9; by[n] = y.toDouble(); n++
        if (n < WIN) return
        val tm = bt.average()
        var s2 = 0.0; var s3 = 0.0; var s4 = 0.0; var sy = 0.0; var suy = 0.0; var su2y = 0.0
        for (i in 0 until WIN) {
            val u = bt[i] - tm; val u2 = u * u
            s2 += u2; s3 += u2 * u; s4 += u2 * u2
            sy += by[i]; suy += u * by[i]; su2y += u2 * by[i]
        }
        val den = s4 - s2 * s2 / WIN - s3 * s3 / s2
        if (abs(den) > 1e-12) {
            val c = (su2y - sy * s2 / WIN - suy * s3 / s2) / den
            val ge = (2 * c).toFloat()
            if (ge in 0.6f..6f) g = 0.85f * g + 0.15f * ge
        }
        val half = WIN / 2
        for (i in 0 until half) { bt[i] = bt[i + half]; by[i] = by[i + half] }
        n = half
    }

    companion object { private const val WIN = 10 }
}
