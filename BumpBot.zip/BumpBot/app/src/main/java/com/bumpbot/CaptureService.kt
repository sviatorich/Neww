package com.bumpbot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Process
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat
import kotlinx.coroutines.flow.update
import kotlin.math.max

/** Передній сервіс: захоплює екран через MediaProjection і передає кадри в Engine. */
class CaptureService : Service() {
    companion object {
        const val ACTION_START = "com.bumpbot.START"
        const val ACTION_STOP = "com.bumpbot.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CH = "bumpbot"
        @Volatile var running = false
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var engine: Engine? = null
    private var px = IntArray(0)
    private var row = ByteArray(0)
    private var fw = 0
    private var fh = 0
    private var stopping = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopAll("Зупинено"); return START_NOT_STICKY }
            ACTION_START -> if (!running) {
                startFg()
                val data = IntentCompat.getParcelableExtra(intent, EXTRA_DATA, Intent::class.java)
                if (data == null) { stopAll("Немає дозволу на запис екрана"); return START_NOT_STICKY }
                try {
                    startCapture(intent.getIntExtra(EXTRA_CODE, 0), data)
                } catch (e: Exception) {
                    stopAll("Помилка захоплення екрана: ${e.message}")
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CH, "Bump Bot", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n: Notification = NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Bump Bot працює")
            .setContentText("Захоплення екрана активне")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "ЗУПИНИТИ", stop)
            .build()
        ServiceCompat.startForeground(
            this, 1, n,
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0
        )
    }

    private fun startCapture(code: Int, data: Intent) {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val t = HandlerThread("bump-vision", Process.THREAD_PRIORITY_DISPLAY).also { it.start() }
        thread = t
        val hd = Handler(t.looper)
        handler = hd

        val mp = mpm.getMediaProjection(code, data)
        projection = mp
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopAll("Захоплення екрана зупинено системою") }
        }, hd)

        val wm = getSystemService(WindowManager::class.java)
        val realW: Int; val realH: Int
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds; realW = b.width(); realH = b.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            realW = dm.widthPixels; realH = dm.heightPixels
        }
        val sc = max(1, realW / 270)           // кадр ≈ 270 px завширшки — достатньо і дуже швидко
        fw = realW / sc; fh = realH / sc
        px = IntArray(fw * fh)
        row = ByteArray(fw * 4)
        engine = Engine(applicationContext, fw, fh, realW, realH)

        val rd = ImageReader.newInstance(fw, fh, PixelFormat.RGBA_8888, 2)
        reader = rd
        rd.setOnImageAvailableListener({ onImage(it) }, hd)
        display = mp.createVirtualDisplay(
            "bump-capture", fw, fh, resources.configuration.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rd.surface, null, hd
        )
        running = true
        BotState.ui.update { it.copy(running = true, status = "Захоплення готове. Натисніть «ПОЧАТИ АВТОГРУ»") }

        hd.post(object : Runnable {
            override fun run() {
                engine?.tick()
                if (running) hd.postDelayed(this, 250)
            }
        })
    }

    private fun onImage(r: ImageReader) {
        val img = try { r.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try {
            val p = img.planes[0]
            val buf = p.buffer
            val rs = p.rowStride
            for (y in 0 until fh) {
                buf.position(y * rs)
                buf.get(row, 0, fw * 4)
                val o = y * fw
                var i = 0
                for (x in 0 until fw) {
                    px[o + x] = ((row[i].toInt() and 255) shl 16) or ((row[i + 1].toInt() and 255) shl 8) or (row[i + 2].toInt() and 255)
                    i += 4
                }
            }
            engine?.onFrame(px, img.timestamp)
        } catch (e: Exception) {
            // пропускаємо пошкоджений кадр
        } finally {
            img.close()
        }
    }

    private fun stopAll(status: String) {
        if (stopping) return
        stopping = true
        running = false
        BotState.armed = false
        handler?.removeCallbacksAndMessages(null)
        try { display?.release() } catch (_: Exception) {}
        try { reader?.setOnImageAvailableListener(null, null); reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        thread?.quitSafely()
        display = null; reader = null; projection = null; thread = null; handler = null; engine = null
        BotState.ui.update { it.copy(running = false, status = status) }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopAll("Зупинено")
        super.onDestroy()
    }
}
