package com.bumpbot

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.MotionEvent
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.bumpbot.databinding.ActivityMainBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private var pending: (() -> Unit)? = null

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == RESULT_OK && data != null) {
                val i = Intent(this, CaptureService::class.java)
                    .setAction(CaptureService.ACTION_START)
                    .putExtra(CaptureService.EXTRA_CODE, r.resultCode)
                    .putExtra(CaptureService.EXTRA_DATA, data)
                ContextCompat.startForegroundService(this, i)
                pending?.invoke()
            } else toast("Дозвіл на запис екрана не надано")
            pending = null
        }

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)

        b.swAuto.isChecked = Prefs.auto
        b.swAuto.setOnCheckedChangeListener { _, v -> Prefs.auto = v }
        b.swRestart.isChecked = Prefs.autoRestart
        b.swRestart.setOnCheckedChangeListener { _, v -> Prefs.autoRestart = v }

        b.seekTol.progress = (Prefs.tol - 20).coerceIn(0, 100)
        b.tvTol.text = "Допуск кольору: ${Prefs.tol}"
        b.seekTol.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                Prefs.tol = 20 + p; b.tvTol.text = "Допуск кольору: ${20 + p}"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        b.btnAcc.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }

        b.btnStart.setOnClickListener {
            if (TapService.instance == null) {
                toast("Спочатку увімкніть «Bump Bot» у Спеціальних можливостях")
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                return@setOnClickListener
            }
            ensureCapture {
                BotState.snapshotAt = 0L
                BotState.armed = true
                launchGame()
            }
        }

        b.btnStop.setOnClickListener {
            BotState.armed = false
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
        }

        b.btnCalib.setOnClickListener {
            ensureCapture {
                BotState.armed = false
                BotState.calibFrame = null
                BotState.snapshotAt = System.currentTimeMillis() + 10_000
                toast("Зараз відкриється гра. Почніть грати: на екрані мають бути качка і перешкода. Знімок через 10 с")
                launchGame()
            }
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                BotState.ui.collect { s ->
                    b.tvStatus.text = s.status
                    b.tvScore.text = s.score.toString()
                    b.tvAttempts.text = "Спроби\n${s.attempts}"
                    b.tvBest.text = "Рекорд\n${s.best}"
                    b.tvLast.text = "Остання\n${s.last}"
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (BotState.calibFrame != null) showCalibDialog()
    }

    private fun ensureCapture(action: () -> Unit) {
        if (CaptureService.running) { action(); return }
        pending = action
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }

    /** Шукає встановлену гру за назвою «Bump» і запускає її. */
    private fun launchGame() {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val hit = pm.queryIntentActivities(q, 0).firstOrNull {
            it.loadLabel(pm).toString().contains("bump", ignoreCase = true) &&
                it.activityInfo.packageName != packageName
        }
        val pkg = hit?.activityInfo?.packageName
        val intent = pkg?.let { pm.getLaunchIntentForPackage(it) }
        if (intent != null) {
            BotState.gamePkg = pkg
            startActivity(intent)
        } else toast("Гру Bump не знайдено — відкрийте її вручну")
    }

    private fun showCalibDialog() {
        val bmp = BotState.calibFrame ?: return
        BotState.calibFrame = null
        val steps = listOf(
            "1/3: торкніться КАЧКИ (по тілу, не по оку/дзьобу)",
            "2/3: торкніться ПЕРЕШКОДИ (труба/стіна, однотонна ділянка)",
            "3/3: торкніться кнопки перезапуску після програшу (або «Пропустити»)"
        )
        var step = 0
        val pad = (12 * resources.displayMetrics.density).toInt()
        val tv = TextView(this).apply { text = steps[0]; setPadding(pad, pad, pad, pad); textSize = 15f }
        val iv = ImageView(this).apply {
            setImageBitmap(bmp); adjustViewBounds = true
            maxHeight = (resources.displayMetrics.heightPixels * 0.6).toInt()
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        val skip = Button(this).apply { text = "Пропустити крок" }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv)
            addView(iv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(skip)
        }
        val dlg = MaterialAlertDialogBuilder(this).setView(box).setNegativeButton("Закрити", null).create()
        fun next() {
            step++
            if (step >= 3) { dlg.dismiss(); toast("Калібрування збережено") } else tv.text = steps[step]
        }
        skip.setOnClickListener { next() }
        iv.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                val view = v as ImageView
                val inv = Matrix()
                if (view.imageMatrix.invert(inv)) {
                    val p = floatArrayOf(e.x - view.paddingLeft, e.y - view.paddingTop)
                    inv.mapPoints(p)
                    val x = p[0].toInt(); val y = p[1].toInt()
                    if (x in 0 until bmp.width && y in 0 until bmp.height) {
                        when (step) {
                            0 -> Prefs.duckColor = sample(bmp, x, y)
                            1 -> Prefs.obstColor = sample(bmp, x, y)
                            2 -> { Prefs.restartX = x / bmp.width.toFloat(); Prefs.restartY = y / bmp.height.toFloat() }
                        }
                        next()
                    }
                }
            }
            true
        }
        dlg.show()
    }

    private fun sample(bmp: Bitmap, x: Int, y: Int): Int {
        var r = 0; var g = 0; var bl = 0; var c = 0
        for (dy in -1..1) for (dx in -1..1) {
            val p = bmp.getPixel((x + dx).coerceIn(0, bmp.width - 1), (y + dy).coerceIn(0, bmp.height - 1))
            r += Color.red(p); g += Color.green(p); bl += Color.blue(p); c++
        }
        return Color.rgb(r / c, g / c, bl / c)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
