package com.bumpbot

import android.graphics.Bitmap
import kotlinx.coroutines.flow.MutableStateFlow

data class UiState(
    val running: Boolean = false,
    val status: String = "Очікування. Натисніть «ПОЧАТИ АВТОГРУ»",
    val score: Int = 0,
    val attempts: Int = 0,
    val best: Int = 0,
    val last: Int = 0
)

/** Спільний стан між інтерфейсом і сервісами (все в одному процесі). */
object BotState {
    val ui = MutableStateFlow(UiState(attempts = Prefs.attempts, best = Prefs.best, last = Prefs.lastScore))
    @Volatile var armed = false          // чи грає бот зараз
    @Volatile var snapshotAt = 0L        // коли зробити знімок для калібрування (мс)
    @Volatile var calibFrame: Bitmap? = null
    @Volatile var gamePkg: String? = null
}
