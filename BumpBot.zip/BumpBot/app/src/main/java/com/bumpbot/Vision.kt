package com.bumpbot

import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

data class Duck(val x: Float, val y: Float, val r: Float)                       // у пікселях кадру
data class Obstacle(val xStart: Int, val xEnd: Int, val gapTop: Int, val gapBottom: Int)
data class Scene(val duck: Duck?, val obstacle: Obstacle?)

/**
 * Розпізнавання по кольору (кольори задає калібрування).
 * Качка = центр мас пікселів кольору качки.
 * Перешкода = колонки, де піксель кольору перешкоди перекриває більшу частину ігрової зони;
 * вільний проміжок = найдовший вертикальний відрізок без кольору перешкоди.
 * Кадр уже зменшений у ~4 рази, тож аналіз займає ~1–2 мс.
 */
class Vision(private val w: Int, private val h: Int) {
    private var dR = 0; private var dG = 0; private var dB = 0
    private var oR = 0; private var oG = 0; private var oB = 0
    private var tol2 = 0
    private var last: Duck? = null
    private var bestS = 0; private var bestE = 0; private var bestLen = 0; private var cnt = 0

    fun reload() {
        val d = Prefs.duckColor; val o = Prefs.obstColor
        dR = (d shr 16) and 255; dG = (d shr 8) and 255; dB = d and 255
        oR = (o shr 16) and 255; oG = (o shr 8) and 255; oB = o and 255
        tol2 = Prefs.tol * Prefs.tol
        last = null
    }

    init { reload() }

    private fun isDuck(p: Int): Boolean {
        val r = ((p shr 16) and 255) - dR; val g = ((p shr 8) and 255) - dG; val b = (p and 255) - dB
        return r * r + g * g + b * b <= tol2
    }

    private fun isObst(p: Int): Boolean {
        val r = ((p shr 16) and 255) - oR; val g = ((p shr 8) and 255) - oG; val b = (p and 255) - oB
        return r * r + g * g + b * b <= tol2
    }

    fun analyze(px: IntArray): Scene {
        val l = last
        var d: Duck? = null
        if (l != null) d = scanDuck(px, max(0, (l.x - 0.12f * w).toInt()), min(w, (l.x + 0.12f * w).toInt()))
        if (d == null) d = scanDuck(px, 0, (0.6f * w).toInt())
        last = d
        val o = if (d != null) findObstacle(px, d) else null
        return Scene(d, o)
    }

    private fun scanDuck(px: IntArray, x0: Int, x1: Int): Duck? {
        var n = 0; var sx = 0L; var sy = 0L
        for (y in 0 until h) {
            val row = y * w
            for (x in x0 until x1) if (isDuck(px[row + x])) { n++; sx += x; sy += y }
        }
        if (n < MIN_PIX) return null
        val cx = (sx / n).toInt(); val cy = (sy / n).toInt()
        val rad = max(6, (sqrt(n / PI) * 2.2).toInt())
        var n2 = 0; var sx2 = 0L; var sy2 = 0L
        for (y in max(0, cy - rad)..min(h - 1, cy + rad)) {
            val row = y * w
            for (x in max(x0, cx - rad)..min(x1 - 1, cx + rad)) if (isDuck(px[row + x])) { n2++; sx2 += x; sy2 += y }
        }
        if (n2 < MIN_PIX) return null
        return Duck(sx2 / n2.toFloat(), sy2 / n2.toFloat(), (sqrt(n2 / PI) * 1.1).toFloat())
    }

    private fun colInfo(px: IntArray, x: Int, top: Int, bot: Int) {
        var run = -1; bestS = 0; bestE = -1; bestLen = 0; cnt = 0
        for (y in top until bot) {
            if (isObst(px[y * w + x])) {
                cnt++
                if (run >= 0) { val len = y - run; if (len > bestLen) { bestLen = len; bestS = run; bestE = y }; run = -1 }
            } else if (run < 0) run = y
        }
        if (run >= 0) { val len = bot - run; if (len > bestLen) { bestLen = len; bestS = run; bestE = bot } }
    }

    private fun findObstacle(px: IntArray, d: Duck): Obstacle? {
        val top = (Prefs.marginTop * h).toInt()
        val bot = ((1f - Prefs.marginBottom) * h).toInt()
        val playH = bot - top
        val minCnt = max(4, (playH * 0.08f).toInt())
        var x = max(0, (d.x - d.r).toInt())
        var xs = -1; var xe = -1; var miss = 0; var n = 0; var sumT = 0L; var sumB = 0L
        while (x < w) {
            colInfo(px, x, top, bot)
            val blocked = cnt >= minCnt && bestLen < 0.9f * playH
            if (blocked) {
                if (xs < 0) xs = x
                xe = x; miss = 0; n++; sumT += bestS; sumB += bestE
            } else if (xs >= 0) {
                miss++
                if (miss > 2) {
                    if (n >= 2) break
                    xs = -1; n = 0; sumT = 0; sumB = 0; miss = 0   // шум з однієї колонки — ігноруємо
                }
            }
            x++
        }
        if (xs < 0 || n < 2) return null
        return Obstacle(xs, xe, (sumT / n).toInt(), (sumB / n).toInt())
    }

    companion object { private const val MIN_PIX = 25 }
}
