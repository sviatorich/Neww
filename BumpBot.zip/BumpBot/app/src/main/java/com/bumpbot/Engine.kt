package com.bumpbot

import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import kotlinx.coroutines.flow.update

/** Автомат станів гри: IDLE → PLAYING → DEAD → (перезапуск) → PLAYING … */
class Engine(
    private val ctx: Context,
    private val w: Int, private val h: Int,
    private val realW: Int, private val realH: Int
) {
    private enum class St { IDLE, PLAYING, DEAD }

    private val vision = Vision(w, h)
    private val pilot = Autopilot(w, h)
    private var st = St.IDLE
    private var lastPx: IntArray? = null
    private var lastFrameNs = System.nanoTime()
    private var lastDuckNs = 0L
    private var deadNs = 0L
    private var attempts = Prefs.attempts
    private var best = Prefs.best
    @Volatile private var pkgOk = false
    private var lockedPkg: String? = null
    private var restartTaps = 0
    private var lastRestartNs = 0L
    private var lastPkgNs = 0L
    private val main = Handler(Looper.getMainLooper())

    private fun ui(status: String? = null, score: Int? = null) {
        BotState.ui.update {
            it.copy(
                running = true, status = status ?: it.status, score = score ?: it.score,
                attempts = attempts, best = best, last = Prefs.lastScore
            )
        }
    }

    /** Кожен кадр з екрана (потік bump-vision). */
    fun onFrame(px: IntArray, ts: Long) {
        val now = System.nanoTime()
        lastFrameNs = now
        lastPx = px
        handleSnapshot(px)
        if (!BotState.armed) { st = St.IDLE; ui(status = "Пауза (бот не запущено)"); return }

        if (st == St.DEAD && now - deadNs < 1_200_000_000L) return   // ігноруємо анімацію «game over»

        val scene = vision.analyze(px)
        if (scene.duck != null) {
            lastDuckNs = now
            if (st != St.PLAYING) startAttempt()
            val allow = Prefs.auto && pkgOk && st == St.PLAYING
            if (pilot.step(scene, ts, allow)) tapGame()
            val status = when {
                !Prefs.auto -> "Спостереження (авторежим вимкнено)"
                !pkgOk -> "Відкрийте гру на екрані — натискання призупинено"
                else -> "Граю… (g=%.2f, стрибок=%.2f)".format(pilot.g, pilot.vj)
            }
            ui(status = status, score = pilot.score)
        } else {
            if (st == St.PLAYING && now - lastDuckNs > 700_000_000L) die()
            else if (st == St.IDLE) ui(status = "Шукаю качку на екрані…")
        }
    }

    /** Таймер-сторож (кожні 250 мс). Кадри не приходять, коли екран нерухомий. */
    fun tick() {
        val now = System.nanoTime()
        checkPkg(now)
        lastPx?.let { handleSnapshot(it) }
        if (!BotState.armed) return
        if (st == St.PLAYING && now - lastFrameNs > 1_000_000_000L) die()
        if (st == St.DEAD) {
            if (restartTaps >= 6) { ui(status = "Гра не відновилась — пауза. Запустіть гру вручну"); return }
            if (Prefs.autoRestart && Prefs.auto && pkgOk && now - lastRestartNs > 1_500_000_000L) {
                lastRestartNs = now; restartTaps++
                TapService.instance?.tap(realW * Prefs.restartX, realH * Prefs.restartY)
                ui(status = "Перезапуск гри ($restartTaps)…")
            }
        }
    }

    private fun startAttempt() {
        pilot.reset(); vision.reload()
        st = St.PLAYING; restartTaps = 0
        lastDuckNs = System.nanoTime()
        ui(score = 0)
    }

    private fun die() {
        st = St.DEAD
        deadNs = System.nanoTime(); lastRestartNs = deadNs; restartTaps = 0
        attempts++
        val sc = pilot.score
        if (sc > best) best = sc
        Prefs.attempts = attempts; Prefs.best = best; Prefs.lastScore = sc
        pilot.onDeath()
        ui(status = "Програш. Рахунок: $sc. ШІ скоригував параметри", score = sc)
    }

    private fun tapGame() {
        TapService.instance?.tap(realW * Prefs.tapX, realH * Prefs.tapY)
    }

    private fun checkPkg(now: Long) {
        if (now - lastPkgNs < 300_000_000L) return
        lastPkgNs = now
        val svc = TapService.instance
        if (svc == null) { pkgOk = false; return }
        val p = svc.foregroundPackage()
        if (p == null) { pkgOk = true; return }
        if (lockedPkg == null) lockedPkg = BotState.gamePkg
        if (lockedPkg == null && st == St.PLAYING && p != ctx.packageName && p !in IGNORE) lockedPkg = p
        // тапаємо лише у грі, ніколи у власному вікні чи на інших застосунках
        pkgOk = p != ctx.packageName && (lockedPkg == null || p == lockedPkg)
    }

    private fun handleSnapshot(px: IntArray) {
        val at = BotState.snapshotAt
        if (at == 0L || System.currentTimeMillis() < at) return
        BotState.snapshotAt = 0L
        val argb = IntArray(w * h) { px[it] or (0xFF shl 24) }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(argb, 0, w, 0, 0, w, h)
        BotState.calibFrame = bmp
        main.post { Toast.makeText(ctx, "Знімок готовий — відкрийте Bump Bot для калібрування", Toast.LENGTH_LONG).show() }
    }

    companion object {
        private val IGNORE = setOf("com.android.systemui", "com.miui.home", "com.mi.android.globallauncher", "com.android.launcher")
    }
}
